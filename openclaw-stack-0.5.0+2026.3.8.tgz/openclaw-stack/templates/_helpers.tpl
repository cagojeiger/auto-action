{{- define "openclaw-stack.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "openclaw-stack.fullname" -}}
{{- if .Values.fullnameOverride -}}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $name := include "openclaw-stack.name" . -}}
{{- if contains $name .Release.Name -}}
{{- .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{- define "openclaw-stack.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "openclaw-stack.labels" -}}
helm.sh/chart: {{ include "openclaw-stack.chart" . }}
app.kubernetes.io/name: {{ include "openclaw-stack.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end -}}

{{- define "openclaw-stack.selectorLabels" -}}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end -}}

{{- define "openclaw-stack.openclawName" -}}
{{- printf "%s-openclaw" (include "openclaw-stack.fullname" .) | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "openclaw-stack.browserlessName" -}}
{{- printf "%s-browserless" (include "openclaw-stack.fullname" .) | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "openclaw-stack.serviceAccountName" -}}
{{- if .Values.serviceAccount.create -}}
{{- default (include "openclaw-stack.fullname" .) .Values.serviceAccount.name -}}
{{- else -}}
{{- default "default" .Values.serviceAccount.name -}}
{{- end -}}
{{- end -}}
